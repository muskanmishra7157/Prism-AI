import os
import shutil

def copy_and_cleanup_txt_files(image_dir, text_src_dir, dest_dir):
    # Ensure destination directory exists
    os.makedirs(dest_dir, exist_ok=True)

    # Get list of all .jpg file names without extension
    jpg_filenames = [os.path.splitext(f)[0] for f in os.listdir(image_dir) if f.lower().endswith('.jpg')]

    for name in jpg_filenames:
        txt_filename = f"{name}.txt"
        src_txt_path = os.path.join(text_src_dir, txt_filename)
        dest_txt_path = os.path.join(dest_dir, txt_filename)

        if os.path.isfile(src_txt_path):
            # Copy the txt file
            shutil.copy2(src_txt_path, dest_txt_path)
            print(f"Copied: {src_txt_path} → {dest_txt_path}")

            # Delete the txt file from source
            os.remove(src_txt_path)
            print(f"Deleted: {src_txt_path}")
        else:
            print(f"Not found: {src_txt_path}")

# Example usage
image_dir = 'val\\images'
text_src_dir = 'train\\labels'
dest_dir = 'val\\labels'

copy_and_cleanup_txt_files(image_dir, text_src_dir, dest_dir)
